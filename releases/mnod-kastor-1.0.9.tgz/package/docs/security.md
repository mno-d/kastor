# Security Model

Kastor exposes local coding capabilities over MCP. Treat it as remote access
to your development machine.

The security model is simple:

- you choose a narrow filesystem allowlist
- the MCP endpoint requires OAuth approval with your Owner password
- Host headers are allowlisted from the configured public URL
- every coding action happens through explicit MCP tool calls

## Filesystem Allowlist

Kastor only opens workspaces under configured roots.

Good examples:

```text
~/work
~/personal/open-source
```

Avoid broad roots:

```text
~
/
C:\
```

The narrower the root, the easier it is to reason about what the MCP client can
reach.

Broad roots are for private machines only. Public examples, templates, and
shared installs should never default to whole-PC access.

Require explicit approval before deletion, large overwrites, uploads, external
sends, installs, payments, permission changes, or publishing.
The shell tool also enforces this in code and blocks risky-looking commands
unless same-turn user approval is represented by `userApproved=true`.

## Owner Password

`kastor init` generates an Owner password and stores it in:

```text
~/.kastor/auth.json
```

When an MCP client connects, Kastor shows an approval page. Enter the Owner
password only when you intentionally want that client to access this server.

For env-driven deployments, set a long random value:

```bash
KASTOR_OAUTH_OWNER_TOKEN="$(openssl rand -base64 32)"
```

## Public URL And Host Allowlist

Kastor needs `KASTOR_PUBLIC_BASE_URL` so MCP clients can discover OAuth
metadata and connect to the correct resource.

The value should be the origin only:

```text
https://your-tunnel-host.example.com
```

Do not include `/mcp` in `KASTOR_PUBLIC_BASE_URL`.

By default, Kastor derives allowed Host headers from the local host and public
URL. Use `KASTOR_ALLOWED_HOSTS=*` only for intentional local debugging.

## Tunnels

Kastor does not manage tunnels. Your tunnel or reverse proxy should point to:

```text
http://127.0.0.1:7676
```

Prefer adding Cloudflare Access, Tailscale identity controls, or equivalent
protection in front of public tunnels. Kastor OAuth still protects the MCP
endpoint, but the tunnel URL should not be treated as a secret.

## Shell Access

The shell tool is powerful by design. It is meant for tests, builds, git, and
package scripts.

Filesystem path containment applies to Kastor file tools. Shell commands run
as local commands and can do what your user account can do. This is why the MCP
client must be trusted and the Owner password must stay private.

## Worktrees

Managed worktrees reduce accidental edits to your active checkout, but they are
not a security boundary. They are a workflow boundary for isolated coding
sessions.

## Logs

By default, Kastor logs requests and tool calls. Shell command previews are
disabled unless `KASTOR_LOG_SHELL_COMMANDS=1`.

Do not enable shell command logging if commands may contain secrets.
